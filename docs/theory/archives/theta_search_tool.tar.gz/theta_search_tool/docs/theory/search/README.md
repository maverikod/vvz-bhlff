# Θ Theory Search Tool - Инструкция по установке и использованию

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

## ⚠️ ВАЖНО: Для поиска индекс НЕ НУЖЕН!

**Для режима `sqlite_search` требуется ТОЛЬКО база данных SQLite.**  
Индекс (`--index`) не используется и не нужен. Для других режимов (`assemble`, `search`, `validate`, `sqlite_build`) индекс обязателен.

## 📦 Распаковка архива

```bash
# Распакуйте архив в /mnt/data/
cd /mnt/data
tar -xzf theta_search_tool.tar.gz

# После распаковки инструмент будет в:
# /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py
```

После распаковки структура будет следующей:

```
theta_search_tool/
├── docs/
│   └── theory/
│       └── search/
│           ├── search_theory_index.py      # Главный скрипт
│           ├── theory_index/               # Модули поиска
│           │   ├── __init__.py
│           │   ├── cli.py
│           │   ├── sqlite_search.py
│           │   ├── query_parser.py
│           │   └── ... (другие модули)
│           ├── README.md                   # Этот файл
│           ├── QUICK_REFERENCE.md          # Краткая справка
│           ├── AI_DOCUMENTATION.md          # Полная документация
│           └── MULTI_DB_MODE.md            # Документация мульти-БД режима
└── theta_launcher.py                        # Скрипт запуска (опционально)
```

## 🔧 Требования

### Python
- Python 3.8 или выше
- Проверка версии: `python3 --version`

### Зависимости
```bash
pip install pyparsing>=3.0.0
```

Или установите все зависимости из `requirements.txt` (если он включён в архив):
```bash
pip install -r requirements.txt
```

## 🚀 Быстрый старт

### ⚡ Поиск (sqlite_search) — БЕЗ индекса!

**Для режима `sqlite_search` индекс НЕ НУЖЕН!** Требуется только база данных SQLite.

**Пути по умолчанию (после распаковки в `/mnt/data/`):**
- Инструмент: `/mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py`
- Базы данных: `/mnt/data/ALL_theory_blocks.chain.part*.sqlite`

#### 1. Простой поиск (автоматическое сканирование по умолчанию)

```bash
# Скрипт автоматически сканирует /mnt/data/ и найдёт все *.sqlite файлы
# ВАЖНО: --index НЕ НУЖЕН для sqlite_search!
# --db-dir по умолчанию = /mnt/data
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --phrase "закон масштаба" \
    --format text
```

**По умолчанию `--db-dir=/mnt/data`** — скрипт автоматически сканирует этот каталог и находит все `.sqlite` файлы.

#### 2. Поиск по одной конкретной базе

```bash
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path /mnt/data/ALL_theory_blocks.chain.part001.sqlite \
    --phrase "закон масштаба" \
    --format text
```

#### 3. Поиск по glob-паттерну

```bash
# БЕЗ --index! Только базы данных
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/mnt/data/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "топологический заряд" \
    --format json
```

**Примечание:** Для режимов `assemble`, `search`, `validate`, `sqlite_build` нужен полный индекс (`--index ALL_index.yaml`). Для `sqlite_search` индекс не используется вообще.

### 4. Логические запросы (AND/OR/NOT)

```bash
# БЕЗ --index!
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/mnt/data/ALL_theory_blocks.chain.part*.sqlite" \
    --query "(глюон OR кварк) AND цвет" \
    --format json \
    --limit 5
```

### 5. Поиск по формулам

```bash
# БЕЗ --index!
python3 docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/path/to/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "K_*" \
    --scope formulas \
    --format json
```

### 6. Поиск с ранжированием и пагинацией

```bash
# БЕЗ --index!
python3 docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/path/to/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "закон" \
    --sort relevance \
    --limit 10 \
    --offset 0 \
    --format json
```

### 7. Экспорт результатов в HTML

```bash
# БЕЗ --index!
python3 docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/path/to/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "масштаб" \
    --export-html results.html \
    --limit 20
```

## 📋 Основные режимы работы

### `sqlite_search` — Поиск по SQLite базе

**⚠️ ВАЖНО: Для этого режима индекс НЕ НУЖЕН!** Требуется только база данных.

Быстрый полнотекстовый поиск с поддержкой:
- Простых фраз (`--phrase`)
- Логических запросов (`--query` с AND/OR/NOT)
- Регулярных выражений (`--regex`)
- Поиска по формулам (`--scope formulas`)
- Мульти-БД режима (`--db-path-glob`)

**Пример (БЕЗ --index):**
```bash
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path /mnt/data/ALL_theory_blocks.chain.part001.sqlite \
    --phrase "искомый текст"
```

### `sqlite_build` — Построение базы
**⚠️ Для этого режима индекс ОБЯЗАТЕЛЕН!**
```bash
python3 docs/theory/search/search_theory_index.py \
    --index docs/theory/ALL_index.yaml \
    --theory docs/theory/All.md \
    --mode sqlite_build \
    --db-path docs/theory/ALL_theory_blocks.sqlite
```

### `assemble` — Сборка сегментов
**⚠️ Для этого режима индекс ОБЯЗАТЕЛЕН!**
```bash
python3 docs/theory/search/search_theory_index.py \
    --index docs/theory/ALL_index.yaml \
    --theory docs/theory/All.md \
    --mode assemble \
    --phrase "CMB" \
    --output-path cmb_blocks.md
```

## 🔍 Формат результатов

### JSON формат
```json
[
  {
    "id": "7d-01",
    "category": "I. Постулаты теории...",
    "summary": "Материя не является...",
    "snippet": "...текст с найденной фразой...",
    "db": "ALL_theory_blocks.chain.part001.sqlite",
    "source_db": "/full/path/to/ALL_theory_blocks.chain.part001.sqlite",
    "part_id": "001"
  }
]
```

### Текстовый формат
```
[id] (database) category :: summary
---
%%id%%
---
<текст блока>
```

## 📚 Дополнительная документация

- **QUICK_REFERENCE.md** — Краткая справка по всем режимам
- **AI_DOCUMENTATION.md** — Полная документация для ИИ-ассистентов
- **MULTI_DB_MODE.md** — Подробное описание мульти-БД режима

## ⚙️ Продвинутые опции

### Регулярные выражения
```bash
--phrase "закон.*масштаб" --regex
```

### Поиск по близости
```bash
--phrase "закон масштаб" --proximity 5
```

### Группировка результатов
```bash
--group-by category
--group-by db
```

### Фильтры по длине
```bash
--min-length 100
--max-length 5000
```

### Подсветка найденных фраз
```bash
--highlight
```

### Контекст вокруг совпадений
```bash
--context 3  # 3 строки до и после
```

## 🐛 Решение проблем

### Ошибка: "ModuleNotFoundError: No module named 'pyparsing'"
```bash
pip install pyparsing>=3.0.0
```

### Ошибка: "No such file or directory: ALL_index.yaml"
Убедитесь, что вы запускаете скрипт из правильной директории или укажите полный путь к индексу:
```bash
--index /full/path/to/ALL_index.yaml
```

### Ошибка: "No database found"
Проверьте путь к базе данных:
```bash
ls -la docs/theory/ALL_theory_blocks*.sqlite
```

## 📝 Примеры использования

### Найти все упоминания "закон масштаба"
```bash
# БЕЗ --index!
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/mnt/data/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "закон масштаба" \
    --format json > results.json
```

### Найти информацию о глюонах и кварках
```bash
# БЕЗ --index!
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/mnt/data/ALL_theory_blocks.chain.part*.sqlite" \
    --query "глюон OR кварк" \
    --format text
```

### Экспортировать результаты в HTML с подсветкой
```bash
# БЕЗ --index!
python3 /mnt/data/theta_search_tool/docs/theory/search/search_theory_index.py \
    --mode sqlite_search \
    --db-path-glob "/mnt/data/ALL_theory_blocks.chain.part*.sqlite" \
    --phrase "топологический заряд" \
    --highlight \
    --export-html charge_results.html \
    --limit 50
```

## 🔗 Контакты

При возникновении проблем или вопросов обращайтесь:
- Email: vasilyvz@gmail.com

---

**Версия:** 2.0 (с поддержкой мульти-БД режима)  
**Дата:** 2025-01-02

