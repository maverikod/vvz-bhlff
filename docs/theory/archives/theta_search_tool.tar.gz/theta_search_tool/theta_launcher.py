#!/usr/bin/env python3
"""Launcher for theta search tool (ChatGPT)."""
import sys
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "docs", "theory", "search"))
exec(open("docs/theory/search/search_theory_index.py").read())
